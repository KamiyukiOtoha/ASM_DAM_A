using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameMap : MonoBehaviour
{
    public GameObject pipePrefab; // tham chiếu đến prefab ống cống
    
    // tạo 1 danh sách các ống cống
    public List<GameObject> pipes;
    
    // thời gian tạo ống cống
    public float timeToCreatePipes;
    // Start is called before the first frame update
    int numberOfPipes = 0;
    void Start()
    {
        timeToCreatePipes = 2f;
    }

    // Update is called once per frame
    void Update()
    {
        timeToCreatePipes -= Time.deltaTime;
        if (timeToCreatePipes <= 0)
        {
            CreateRandomPipes();
            timeToCreatePipes = 2f;
        }
    }
    
    // hàm tạo ngẫu nhiên ống cống tại 1 vị trí
    private void CreateRandomPipes()
    {
        // tạo ống cống ngẫu nhiên ngoài màn hình
        var randomY = Random.Range(-3f, 3f);
        var pipe = Instantiate(pipePrefab,
            new Vector3(10, randomY, 0), Quaternion.identity);
        Destroy(pipe, 10);
        // di chuyển ống cống qua trái
        MovePipes(pipe);
    }
    
    // hàm di chuyển ống cống qua trái
    private void MovePipes(GameObject pipe)
    {
        // di chuyển ống cống qua trái
        pipe.GetComponent<Rigidbody2D>().velocity = Vector2.left * 2;
    }
}
